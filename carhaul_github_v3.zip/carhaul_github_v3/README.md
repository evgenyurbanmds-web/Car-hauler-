# CarHaul Tracker v3

Static mobile-first PWA for GitHub Pages.

## GitHub Pages
1. Create a public GitHub repository, for example `carhaul-tracker`.
2. Upload `index.html`, `manifest.webmanifest`, and `sw.js` to the repository root.
3. Open Settings → Pages.
4. Under Build and deployment choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Open the Pages URL on iPhone and allow Location access.

## v3 additions
- Finished trips are archived in **History**.
- History cards show miles, revenue, profit, fuel, MPG and vehicle count.
- Tap a trip to see its route on an OpenStreetMap map plus event markers and timeline.
- Current v2 browser data is migrated automatically when possible.

## Important test limitation
Trip data is stored in browser localStorage. Clearing Safari site data can erase it. iOS can also suspend browser GPS in the background.
